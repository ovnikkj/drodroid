package com.example.form.models

class Pessoa (
     var nome: String,
     var email: String
){

}