package com.example.myapplication.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun GameSearchBar(
    label: String,
    searchText: String,
    onSearchTextChange: (String) -> Unit,
    onSearch: (String) -> String,
    onClear:() -> Unit
) {
Column(Modifier.fillMaxWidth()) {
    OutlinedTextField(value = searchText,
        onValueChange = onSearchTextChange,
        label = { Text(label) },
        trailingIcon = {IconButton(onClick = {onSearch(searchText)}) {
            Icon(Icons.Default.Search,contentDescription = null)
        }}
    )
    if(searchText.isNotEmpty()){
        Row {

        }
    }
}
}
